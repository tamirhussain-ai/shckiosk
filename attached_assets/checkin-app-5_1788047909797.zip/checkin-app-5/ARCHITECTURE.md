# IU SHC Custom Check-In App — Architecture

## Approach: hybrid client, not a full native-protocol clone

Two integration paths are available, and they're not equally solid:

- **Native kiosk protocol** (`frmPurpose` calls against eCW's `mobiledoc` webapp, activation code + `rk` header, session cookie): this is what we reverse-engineered from the decompiled servlet. It's undocumented and unsupported — eCW owes you nothing about its stability across version upgrades, and it wasn't designed for anyone but their own native app to call it.
- **REST API** (`ehr-restful-api-main`, ASP.NET Core, already in production for the online scheduler): documented-enough for you to have already built against it, and presumably something eCW knows you're using.

Recommendation baked into this build: **use the REST API wherever it already covers a step** (encounters, visit types, booking), **fall back to the native protocol only for what nothing else exposes** — chiefly the actual check-in status write (`appntCheckIn` / `setVisitStatusForEvent`, which is what updates the patient-tracking board) and whatever screens the REST API doesn't cover yet. This isn't a hard rule, it's a starting posture — flip individual steps between clients as you learn what the REST API actually supports.

Both clients sit behind one internal interface (`CheckInBackend`) so the frontend never knows or cares which one answered.

## Two things to sort out before this touches production

1. **The `saveSignature` hardcoded boundary.** eCW's servlet parses the multipart body looking for the literal boundary string `WebKitFormBoundarycC4YiaUFwM44F6rT` rather than reading it out of the `Content-Type` header like a normal multipart parser would. That's either a vendor bug or an artifact of how their native app's HTTP library happens to generate boundaries — either way, our client has to send that exact string to be parsed correctly, and it's exactly the kind of implementation detail that can silently change in a future eCW patch with no changelog entry you'd see. Build in a clear failure mode here (log the raw response, don't just swallow a parse failure), and re-verify this against a test/sandbox eCW instance before rolling to any real iPad.
2. **Vendor relationship.** Talking directly to an internal servlet that wasn't published as a public integration point is a different conversation with your eCW account rep than "we use your REST API." Worth a heads-up to them before this goes anywhere near a real patient, both so it doesn't look like unauthorized access from their monitoring side, and because they may simply tell you which parts they'd rather you use the REST API for.

## Layers

```
frontend/index.html          — wizard UI, IU crimson/cream, one screen per stage
        |  fetch() calls to our own Flask backend only — never touches eCW directly
backend/app.py                — Flask app, exposes clean /api/* endpoints for the wizard
backend/checkin_backend.py    — CheckInBackend: picks native vs REST per step, uniform interface
backend/ecw_native_client.py  — reimplementation of the frmPurpose protocol
backend/ecw_rest_client.py    — thin wrapper around ehr-restful-api-main
backend/config.py             — facility activation code, regkey, hosts, per-step routing table
```

## Wizard stages (maps 1:1 to the reference doc)

| # | Stage | Client used (default) | eCW action(s) |
|---|---|---|---|
| 1 | Identify patient | native | `validateUser`, duplicate handling, phone/OTP fallback |
| 2 | Select appointment | REST (falls back to native) | `getPatientEncounters` |
| 3 | Confirm demographics | native | `getPatientContacts`, `getPatientResponsibleParty`, `updateDemographics` |
| 4 | Confirm insurance | native | `getInsuranceList`, `verifyElig`, `logInsuranceAccepted/Rejected` |
| 5 | Consent & signature | native | `getConsentFormsForNewPatient`, `saveSignature` |
| 6 | Questionnaire | **your own MySQL renderer**, not eCW's `getQuestionnaire`/`saveQuestionnaire` | reuses the branching-questionnaire prototype you already built and tested against `questionnaireformdesign`/`questionnairedata` |
| 7 | Medical/surgical/immunization history | native | `getMedicalHistories`, `saveSurgicalHistory`, `getImmunizationQuestionnaire` |
| 8 | Check-in | native (this one has to be) | `appntCheckIn`, `setVisitStatusForEvent` |
| 9 | Complete | native | `saveKioskTasks`, `logout` |

Stage 6 deliberately skips eCW's own questionnaire protocol — you already have a working, tested implementation of that exact piece against your own DB, no reason to re-derive it from a reverse-engineered servlet when you have something better.

## What's mocked right now

No live eCW host, activation code, or regkey were provided, so `ecw_native_client.py` is structurally complete (real endpoint paths, real header/param shapes, real multipart boundary handling) but runs in `MOCK_MODE` by default, returning realistic canned XML instead of hitting a real server. Flip `MOCK_MODE = False` in `config.py` and fill in `FACILITY_ACTIVATION_CODE`, `REG_KEY`, and `ECW_HOST` once you're pointed at a test instance.
