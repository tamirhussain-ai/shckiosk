"""
Stage 6 (questionnaire) deliberately does NOT call eCW's getQuestionnaire /
saveQuestionnaire. You already have a working, tested branching-questionnaire
renderer against questionnaireformdesign / questionnairedata — this module
is a thin seam to plug that existing implementation in, not a reimplementation
of it.

An appointment can carry more than one questionnaire (e.g. "Reason for
Visit" plus a screening tool like PHQ-9), and some may already be filled
out from the patient portal ahead of time — those should show as
review-only, not be re-asked. get_questionnaire_list is the new entry
point for that; get_questionnaire/save_answers are scoped to one named
questionnaire now instead of a single implicit one.

Replace the bodies below with calls into your existing renderer's backend
(or import it directly if it's already a Python module).
"""

import config


class QuestionnaireBackend:
    def get_questionnaire_list(self, patient_id, encounter_id=None):
        """
        Returns every questionnaire assigned to this visit, each with a
        status: "not_started" (needs to be filled out at the kiosk) or
        "completed_portal" (patient already answered it ahead of time —
        show as review-only, don't re-ask).
        """
        if config.MOCK_MODE:
            return {
                "questionnaires": [
                    {"name": "Reason for Visit", "status": "not_started"},
                    {"name": "PHQ-9 Depression Screening", "status": "completed_portal"},
                ]
            }
        # TODO: wire in the real query — which questionnaires are assigned
        # to this visit, and whether questionnairedata already has an
        # answer set for each (submitted via the patient portal).
        raise NotImplementedError("Plug in the existing renderer's DB access here")

    def get_questionnaire(self, questionnaire_name="Reason for Visit"):
        if config.MOCK_MODE:
            if questionnaire_name == "PHQ-9 Depression Screening":
                return {
                    "questions": [
                        {
                            "id": "PHQ_1", "seqNo": 1,
                            "text": "Little interest or pleasure in doing things?",
                            "type": "single_select", "mandatory": True,
                            "options": [
                                {"id": "0", "label": "Not at all"}, {"id": "1", "label": "Several days"},
                                {"id": "2", "label": "More than half the days"}, {"id": "3", "label": "Nearly every day"},
                            ],
                        },
                    ]
                }
            return {
                "questions": [
                    {
                        "id": "IN_8463",
                        "seqNo": 1,
                        "text": "What is the primary reason for your visit today?",
                        "type": "free_text",
                        "mandatory": True,
                    },
                    {
                        "id": "IN_8471",
                        "seqNo": 2,
                        "text": "Have you had a fever in the last 24 hours?",
                        "type": "single_select",
                        "options": [{"id": "1", "label": "Yes"}, {"id": "2", "label": "No"}],
                        "mandatory": True,
                    },
                ]
            }
        # TODO: wire in the real query against questionnaireformdesign,
        # WHERE doctype LIKE '-master%', sorted by SeqNo, same logic
        # your existing renderer already implements.
        raise NotImplementedError("Plug in the existing renderer's DB access here")

    def get_questionnaire_answers(self, patient_id, questionnaire_name):
        """
        Read-only: previously submitted answers for a questionnaire the
        patient already completed via the portal, for the review screen.
        """
        if config.MOCK_MODE:
            if questionnaire_name == "PHQ-9 Depression Screening":
                return {
                    "answers": [
                        {"question": "Little interest or pleasure in doing things?", "answer": "Not at all"},
                    ]
                }
            return {"answers": []}
        # TODO: read the existing <Questionnaire>...</Questionnaire> blob
        # from questionnairedata for this patient/questionnaire and map it
        # back to question text using questionnaireformdesign, same
        # lookup direction your renderer already does in reverse.
        raise NotImplementedError("Plug in the existing renderer's DB access here")

    def save_answers(self, patient_id, questionnaire_name, answers: dict):
        if config.MOCK_MODE:
            return {"status": "ok"}
        # TODO: write back to questionnairedata as the
        # <Questionnaire><IN_8463>...</IN_8463>...</Questionnaire> XML blob,
        # same write-back format your existing renderer already produces.
        raise NotImplementedError("Plug in the existing renderer's write-back here")
