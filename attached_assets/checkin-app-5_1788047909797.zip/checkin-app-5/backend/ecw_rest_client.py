"""
Wrapper around ehr-restful-api-main (ASP.NET Core), the documented REST API
already used by the online scheduler. Prefer this client over
ecw_native_client wherever it actually covers a step — see
config.STEP_CLIENT for the routing.

Endpoint paths below are placeholders; wire them up to match whatever
ehr-restful-api-main actually exposes (check the online-scheduler codebase
for the real routes rather than guessing further here).
"""

import requests

import config


class EcwRestClient:
    def __init__(self):
        self.base_url = config.REST_API_BASE.rstrip("/")

    def _headers(self):
        return {"Authorization": f"Bearer {config.REST_API_KEY}"}

    def get_patient_encounters(self, patient_id):
        if config.MOCK_MODE:
            return {
                "encounters": [
                    {
                        "id": "55231",
                        "provider": "Dr. Alvarez",
                        "visitType": "Follow-up",
                        "time": "10:30 AM",
                        "department": "2nd Floor Medical",
                        "floor": "2nd",
                    }
                ]
            }
        resp = requests.get(
            f"{self.base_url}/patients/{patient_id}/encounters",
            headers=self._headers(),
            timeout=15,
        )
        resp.raise_for_status()
        return resp.json()
