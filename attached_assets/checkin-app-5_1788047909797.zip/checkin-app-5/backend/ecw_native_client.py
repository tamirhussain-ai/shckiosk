"""
Client for eCW's native iPad kiosk protocol, reconstructed from the
decompiled servlet.IpadKioskProcessor.

This talks to an UNDOCUMENTED, UNSUPPORTED interface. Every action name,
parameter name, and the saveSignature boundary quirk below came from
reading eCW's own dispatch code, not from any published API contract.
Treat every method here as something to re-verify against a test eCW
instance, and expect it to need updates across eCW version upgrades.
"""

import uuid
import xml.etree.ElementTree as ET

import requests

import config


class EcwNativeClient:
    def __init__(self):
        self.session = requests.Session()
        self.base_url = config.ECW_HOST.rstrip("/") + config.ECW_KIOSK_PATH

    # -- low-level plumbing -------------------------------------------------

    def _headers(self):
        # `rk` is read via request.getHeader("rk") in the decompiled servlet,
        # checked against the facility's registration key before anything
        # else runs (validateRequestForActCodeAndRegKey).
        return {"rk": config.REG_KEY}

    def _post(self, frm_purpose, data=None, files=None):
        if config.MOCK_MODE:
            return self._mock_response(frm_purpose, data)

        payload = {"frmPurpose": frm_purpose}
        if data:
            payload.update(data)

        resp = self.session.post(
            self.base_url,
            data=payload,
            files=files,
            headers=self._headers(),
            timeout=15,
        )
        resp.raise_for_status()
        return resp.text

    @staticmethod
    def _build_form_data_xml(item_fields: dict) -> str:
        """
        Mirrors the <item><FirstName/>...</item> shape validateUser's
        inline XML parsing expects (CwXmlHelper.getChildTagValue calls
        against oDocResponse.getElementsByTagName("item")).
        """
        root = ET.Element("root")
        item = ET.SubElement(root, "item")
        for tag, value in item_fields.items():
            child = ET.SubElement(item, tag)
            child.text = "" if value is None else str(value)
        return ET.tostring(root, encoding="unicode")

    # -- stage 1: identify patient ------------------------------------------

    def validate_user(self, first_name, last_name, dob, facility_id=None):
        """
        Mirrors the inline validateUser logic (IpadKioskProcessor lines
        114-342). Returns a dict: {"status": "ok"|"not_found"|"duplicate",
        "patient_id": ..., "phone_verification_required": bool}
        """
        form_data = self._build_form_data_xml(
            {
                "FirstName": first_name,
                "LastName": last_name,
                "DOB": dob,
                "facId": facility_id or config.FACILITY_ID,
            }
        )
        raw = self._post("validateUser", {"formData": form_data})
        return self._parse_validate_user_response(raw)

    @staticmethod
    def _parse_validate_user_response(raw_xml: str) -> dict:
        root = ET.fromstring(raw_xml)
        status = root.findtext("status", default="failed")
        if status == "ok":
            return {"status": "ok", "patient_id": root.findtext("patientId")}
        error_code = root.findtext("errorCode", default="")
        if error_code == "-2" or error_code == "-3":
            phone_required = root.findtext("phoneNumberValidationRequired") == "1"
            return {"status": "duplicate", "phone_verification_required": phone_required}
        return {"status": "not_found"}

    def validate_by_account_number(self, account_number, dob):
        """
        University-ID-based lookup. Mapped to eCW's `validateAccountNumber`
        action (dispatch line 1560 in the decompiled processor) — this is
        an inference from the action name, not something we saw the actual
        implementation of, so re-verify the response shape against a real
        test instance.
        """
        form_data = self._build_form_data_xml(
            {"accountNumber": account_number, "DOB": dob, "facId": config.FACILITY_ID}
        )
        raw = self._post("validateAccountNumber", {"formData": form_data})
        return self._parse_validate_user_response(raw)

    def validate_by_last_name(self, last_name, dob, facility_id=None):
        """
        Last-name-only identification. Reuses validateUser's own inline
        logic (IpadKioskProcessor lines 114-342) with FirstName left blank
        — the servlet doesn't require it, it's just one of the fields the
        XML payload carries.
        """
        return self.validate_user("", last_name, dob, facility_id)

    def authenticate_using_phone_number(self, phone_number, session_token):
        form_data = self._build_form_data_xml({"phoneNumber": phone_number})
        return self._post(
            "authPhoneNumber", {"formData": form_data, "sessionToken": session_token}
        )

    def send_otp(self, patient_id):
        form_data = self._build_form_data_xml({"patientId": patient_id})
        return self._post("sendOTP", {"formData": form_data})

    def verify_otp(self, patient_id, code):
        form_data = self._build_form_data_xml({"patientId": patient_id, "otp": code})
        return self._post("verifyOTP", {"formData": form_data})

    # -- stage 2: encounters --------------------------------------------------

    def get_patient_encounters(self, patient_id):
        form_data = self._build_form_data_xml({"patientId": patient_id})
        return self._post("getPatientEncounters", {"formData": form_data})

    def verify_qr_checkin(self, patient_id, encounter_id):
        """
        NOT an eCW action — there's no reverse-engineered `getQRCode`-adjacent
        verification endpoint for this. A scanned QR code is just a string
        the patient is holding; before trusting it, we independently pull
        that patient's encounters and confirm the scanned encounter_id is
        actually one of them, rather than checking the patient in on the
        strength of the QR payload alone. Also returns the matched
        encounter's details, since the QR path skips the normal encounter
        fetch step entirely and the completion screen still needs them.
        """
        raw = self.get_patient_encounters(patient_id)
        try:
            root = ET.fromstring(raw)
            for e in root.iter("encounter"):
                if e.get("id") == encounter_id:
                    return {
                        "valid": True,
                        "encounter": {
                            "id": e.get("id"), "provider": e.get("provider"),
                            "visitType": e.get("visitType"), "time": e.get("time"),
                            "department": e.get("department"), "floor": e.get("floor"),
                        },
                    }
            return {"valid": False, "encounter": None}
        except ET.ParseError:
            return {"valid": False, "encounter": None}

    # -- stage 3: demographics --------------------------------------------------

    def get_patient_contacts(self, patient_id):
        form_data = self._build_form_data_xml({"patientId": patient_id})
        return self._post("getPatientContacts", {"formData": form_data})

    def update_demographics(self, patient_id, fields: dict):
        merged = {"patientId": patient_id, **fields}
        form_data = self._build_form_data_xml(merged)
        return self._post("updateDemographics", {"formData": form_data})

    def log_verified_demographics(self, patient_id):
        form_data = self._build_form_data_xml({"patientId": patient_id})
        return self._post("logVerifiedDemographics", {"formData": form_data})

    # -- stage 4: insurance --------------------------------------------------

    def get_insurance_list(self, patient_id):
        form_data = self._build_form_data_xml({"patientId": patient_id})
        return self._post("getInsuranceList", {"formData": form_data})

    def verify_eligibility(self, patient_id, insurance_id):
        form_data = self._build_form_data_xml(
            {"patientId": patient_id, "insuranceId": insurance_id}
        )
        return self._post("verifyElig", {"formData": form_data})

    def log_insurance_decision(self, patient_id, accepted: bool):
        purpose = "logInsuranceAccepted" if accepted else "logInsuranceRejected"
        form_data = self._build_form_data_xml({"patientId": patient_id})
        return self._post(purpose, {"formData": form_data})

    def log_self_pay(self, patient_id):
        """
        NOT a reverse-engineered eCW action — the dispatch table never
        surfaced anything named for self-pay specifically. Reusing
        logInsuranceRejected as the closest existing logging hook for
        "no insurance to record" until you confirm whether eCW has a
        distinct self-pay/financial-class action of its own.
        """
        form_data = self._build_form_data_xml({"patientId": patient_id, "paymentMethod": "self-pay"})
        return self._post("logInsuranceRejected", {"formData": form_data})

    def save_insurance_card(self, patient_id, image_png_bytes):
        """
        Mapped to eCW's `saveInsuranceCards` action (dispatch line 2648).
        We don't have the real implementation's multipart shape confirmed —
        following the same pattern as saveSignature is a reasonable guess,
        but re-verify against a test instance before relying on it.
        """
        if config.MOCK_MODE:
            return self._mock_response("saveInsuranceCards", {})
        form_data = self._build_form_data_xml({"patientId": patient_id})
        files = {"cardImage": ("insurance_card.png", image_png_bytes, "image/png")}
        return self._post("saveInsuranceCards", {"formData": form_data}, files=files)

    # -- stage 5: consent & signature --------------------------------------------------

    def get_consent_forms_for_patient(self, patient_id):
        form_data = self._build_form_data_xml({"patientId": patient_id})
        return self._post("getConsentFormsForNewPatient", {"formData": form_data})

    def save_signature(self, patient_id, form_type, signature_png_bytes):
        """
        eCW's saveSignature handler parses the multipart body looking for
        the literal boundary string in config.SAVE_SIGNATURE_BOUNDARY
        rather than reading it out of Content-Type — so we send exactly
        that boundary rather than letting `requests` generate a random one.
        """
        boundary = config.SAVE_SIGNATURE_BOUNDARY
        parts = []

        def add_field(name, value):
            parts.append(
                f'--{boundary}\r\nContent-Disposition: form-data; name="{name}"\r\n\r\n{value}\r\n'
            )

        add_field("formAcceptNature", form_type)
        add_field("patientId", patient_id)

        parts.append(
            f'--{boundary}\r\nContent-Disposition: form-data; name="signatureImage"; '
            f'filename="signature.png"\r\nContent-Type: image/png\r\n\r\n'
        )
        body = "".join(parts).encode("utf-8") + signature_png_bytes + f"\r\n--{boundary}--\r\n".encode("utf-8")

        if config.MOCK_MODE:
            return self._mock_response("saveSignature", {})

        headers = self._headers()
        headers["Content-Type"] = f"multipart/form-data; boundary={boundary}"
        resp = self.session.post(
            self.base_url,
            params={"frmPurpose": "saveSignature"},
            data=body,
            headers=headers,
            timeout=15,
        )
        resp.raise_for_status()
        return resp.text

    # -- stage 6: NOTE — questionnaire deliberately not implemented here. --
    # Use your own MySQL-based branching renderer (questionnaireformdesign /
    # questionnairedata) instead of eCW's getQuestionnaire/saveQuestionnaire.
    # See checkin_backend.py.

    # -- stage 7: history --------------------------------------------------

    def get_medical_histories(self, patient_id):
        form_data = self._build_form_data_xml({"patientId": patient_id})
        return self._post("getMedicalHistories", {"formData": form_data})

    def save_surgical_history(self, patient_id, entries: list):
        form_data = self._build_form_data_xml(
            {"patientId": patient_id, "entries": "|".join(entries)}
        )
        return self._post("saveSurgicalHistory", {"formData": form_data})

    def get_immunization_questionnaire(self, patient_id):
        form_data = self._build_form_data_xml({"patientId": patient_id})
        return self._post("getImmunizationQuestionnaire", {"formData": form_data})

    def save_immunization_questionnaire(self, patient_id, answers: dict):
        merged = {"patientId": patient_id, **answers}
        form_data = self._build_form_data_xml(merged)
        return self._post("saveImmunizationQuestionnaire", {"formData": form_data})

    # -- stage 8: check-in (the write that matters) --------------------------------------------------

    def appnt_check_in(self, patient_id, encounter_id):
        form_data = self._build_form_data_xml(
            {"patientId": patient_id, "encounterId": encounter_id}
        )
        return self._post("appntCheckIn", {"formData": form_data})

    def set_visit_status_for_event(self, encounter_id, status):
        form_data = self._build_form_data_xml(
            {"encounterId": encounter_id, "status": status}
        )
        return self._post("setVisitStatusForEvent", {"formData": form_data})

    # -- stage 9: completion --------------------------------------------------

    def save_kiosk_tasks(self, patient_id, tasks_completed: list):
        form_data = self._build_form_data_xml(
            {"patientId": patient_id, "tasks": "|".join(tasks_completed)}
        )
        return self._post("saveKioskTasks", {"formData": form_data})

    def logout(self):
        return self._post("logout", {})

    # -- mock responses for local development / demo --------------------------------------------------

    def _mock_response(self, frm_purpose, data):
        mocks = {
            "validateUser": '<response><status>ok</status><patientId>10482</patientId></response>',
            "validateAccountNumber": '<response><status>ok</status><patientId>10482</patientId></response>',
            "getPatientEncounters": (
                '<response><status>ok</status><encounters>'
                '<encounter id="55231" provider="Dr. Alvarez" visitType="Follow-up" '
                'time="10:30 AM" department="2nd Floor Medical" floor="2nd"/>'
                '</encounters></response>'
            ),
            "getPatientContacts": (
                '<response><status>ok</status>'
                '<demographics address="123 E 10th St" city="Bloomington" state="IN" '
                'zip="47405" phone="812-555-0134"/>'
                '</response>'
            ),
            "updateDemographics": '<response><status>ok</status></response>',
            "logVerifiedDemographics": '<response><status>ok</status></response>',
            "getInsuranceList": (
                '<response><status>ok</status><insurances>'
                '<insurance id="1" payer="Anthem BCBS" memberId="XYZ123456" '
                'groupNumber="GRP-88213" subscriberName="Jane Doe" primary="true"/>'
                '</insurances></response>'
            ),
            "saveInsuranceCards": '<response><status>ok</status></response>',
            "verifyElig": '<response><status>ok</status><eligible>true</eligible></response>',
            "logInsuranceAccepted": '<response><status>ok</status></response>',
            "logInsuranceRejected": '<response><status>ok</status></response>',
            "getConsentFormsForNewPatient": (
                '<response><status>ok</status><forms>'
                '<form id="hipaa" title="HIPAA Notice of Privacy Practices" requiresSignature="true"/>'
                '<form id="roi" title="Release of Information" requiresSignature="true"/>'
                '</forms></response>'
            ),
            "saveSignature": '<response><status>ok</status></response>',
            "getMedicalHistories": (
                '<response><status>ok</status><history>'
                '<condition name="Seasonal allergies" status="active"/>'
                '</history></response>'
            ),
            "saveSurgicalHistory": '<response><status>ok</status></response>',
            "getImmunizationQuestionnaire": (
                '<response><status>ok</status><questions>'
                '<question id="q1" text="Any new allergies since your last visit?"/>'
                '</questions></response>'
            ),
            "saveImmunizationQuestionnaire": '<response><status>ok</status></response>',
            "appntCheckIn": '<response><status>ok</status></response>',
            "setVisitStatusForEvent": '<response><status>ok</status></response>',
            "saveKioskTasks": '<response><status>ok</status></response>',
            "logout": '<response><status>ok</status></response>',
        }
        return mocks.get(frm_purpose, '<response><status>ok</status><mock>true</mock></response>')
