"""
CheckInBackend is the single interface the Flask routes talk to. It
decides, per step, whether to call the native eCW protocol client or the
REST API client, per config.STEP_CLIENT — so the routing table is the one
place you change as you learn what the REST API actually covers.
"""

import config
from ecw_native_client import EcwNativeClient
from ecw_rest_client import EcwRestClient
from questionnaire_backend import QuestionnaireBackend


class CheckInBackend:
    def __init__(self):
        self.native = EcwNativeClient()
        self.rest = EcwRestClient()
        self.questionnaire = QuestionnaireBackend()

    def _client_for(self, step):
        return self.native if config.STEP_CLIENT.get(step, "native") == "native" else self.rest

    # -- stage 1 --------------------------------------------------
    def identify_patient(self, first_name, last_name, dob):
        return self.native.validate_user(first_name, last_name, dob)

    def identify_by_university_id(self, university_id, dob):
        return self.native.validate_by_account_number(university_id, dob)

    def identify_by_last_name(self, last_name, dob):
        return self.native.validate_by_last_name(last_name, dob)

    def verify_qr_checkin(self, patient_id, encounter_id):
        return self.native.verify_qr_checkin(patient_id, encounter_id)

    def send_otp(self, patient_id):
        return self.native.send_otp(patient_id)

    def verify_otp(self, patient_id, code):
        return self.native.verify_otp(patient_id, code)

    # -- stage 2 --------------------------------------------------
    def get_encounters(self, patient_id):
        client = self._client_for("get_encounters")
        return client.get_patient_encounters(patient_id)

    # -- stage 3 --------------------------------------------------
    def get_demographics(self, patient_id):
        return self.native.get_patient_contacts(patient_id)

    def update_demographics(self, patient_id, fields):
        self.native.update_demographics(patient_id, fields)
        return self.native.log_verified_demographics(patient_id)

    # -- stage 4 --------------------------------------------------
    def get_insurance(self, patient_id):
        return self.native.get_insurance_list(patient_id)

    def confirm_insurance(self, patient_id, insurance_id, accepted, fields=None):
        if accepted:
            self.native.verify_eligibility(patient_id, insurance_id)
        return self.native.log_insurance_decision(patient_id, accepted)

    def log_self_pay(self, patient_id):
        return self.native.log_self_pay(patient_id)

    def save_insurance_card(self, patient_id, image_png_bytes):
        return self.native.save_insurance_card(patient_id, image_png_bytes)

    # -- stage 5 --------------------------------------------------
    def get_consent_forms(self, patient_id):
        return self.native.get_consent_forms_for_patient(patient_id)

    def save_signature(self, patient_id, form_type, signature_png_bytes):
        return self.native.save_signature(patient_id, form_type, signature_png_bytes)

    # -- stage 6 --------------------------------------------------
    def get_questionnaire_list(self, patient_id, encounter_id=None):
        return self.questionnaire.get_questionnaire_list(patient_id, encounter_id)

    def get_questionnaire(self, questionnaire_name):
        return self.questionnaire.get_questionnaire(questionnaire_name)

    def get_questionnaire_answers(self, patient_id, questionnaire_name):
        return self.questionnaire.get_questionnaire_answers(patient_id, questionnaire_name)

    def save_questionnaire_answers(self, patient_id, questionnaire_name, answers):
        return self.questionnaire.save_answers(patient_id, questionnaire_name, answers)

    # -- stage 7 --------------------------------------------------
    def get_medical_history(self, patient_id):
        return self.native.get_medical_histories(patient_id)

    def save_surgical_history(self, patient_id, entries):
        return self.native.save_surgical_history(patient_id, entries)

    def get_immunization_questionnaire(self, patient_id):
        return self.native.get_immunization_questionnaire(patient_id)

    def save_immunization_answers(self, patient_id, answers):
        return self.native.save_immunization_questionnaire(patient_id, answers)

    # -- stage 8 --------------------------------------------------
    def check_in(self, patient_id, encounter_id):
        self.native.appnt_check_in(patient_id, encounter_id)
        return self.native.set_visit_status_for_event(encounter_id, "checked-in")

    # -- stage 9 --------------------------------------------------
    def complete_visit(self, patient_id, tasks_completed):
        self.native.save_kiosk_tasks(patient_id, tasks_completed)
        return self.native.logout()
