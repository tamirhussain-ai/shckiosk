"""
Flask backend for the custom check-in app. The frontend only ever calls
these /api/* routes — it never talks to eCW directly, since the native
protocol needs server-side session/cookie handling and credentials that
have no business being in browser JS.

Run:
    pip install flask requests --break-system-packages
    python app.py
Then open frontend/index.html (served separately, or point it at
http://localhost:5000 if you serve it from Flask too).
"""

import base64

from flask import Flask, jsonify, request, send_from_directory

from checkin_backend import CheckInBackend

app = Flask(__name__, static_folder="../frontend", static_url_path="")
backend = CheckInBackend()


@app.route("/")
def index():
    return send_from_directory(app.static_folder, "index.html")


@app.route("/api/identify", methods=["POST"])
def identify():
    """
    Single endpoint for all three identification methods, discriminated
    by "method". QR is handled separately below since it skips straight
    to verification rather than a name/ID + DOB lookup.
    """
    body = request.get_json()
    method = body.get("method", "lastName")
    if method == "universityId":
        result = backend.identify_by_university_id(body["universityId"], body["dob"])
    elif method == "lastName":
        result = backend.identify_by_last_name(body["lastName"], body["dob"])
    else:
        return jsonify({"status": "failed", "error": f"unknown method {method}"}), 400
    return jsonify(result)


@app.route("/api/identify/qr", methods=["POST"])
def identify_qr():
    """
    QR payload already carries both patientId and encounterId (encoded by
    whatever issues the code — e.g. an appointment confirmation). We still
    verify server-side that the encounter actually belongs to that patient
    before trusting it, rather than checking in on the strength of a
    client-decoded string alone.
    """
    body = request.get_json()
    result = backend.verify_qr_checkin(body["patientId"], body["encounterId"])
    if result.get("valid"):
        return jsonify({
            "status": "ok",
            "patient_id": body["patientId"],
            "encounter_id": body["encounterId"],
            "encounter": result.get("encounter"),
        })
    return jsonify({"status": "invalid"})


@app.route("/api/send-otp", methods=["POST"])
def send_otp():
    body = request.get_json()
    backend.send_otp(body["patientId"])
    return jsonify({"status": "sent"})


@app.route("/api/verify-otp", methods=["POST"])
def verify_otp():
    body = request.get_json()
    raw = backend.verify_otp(body["patientId"], body["code"])
    return jsonify({"status": "ok", "raw": raw})


@app.route("/api/encounters/<patient_id>", methods=["GET"])
def encounters(patient_id):
    raw = backend.get_encounters(patient_id)
    return jsonify({"raw": raw}) if isinstance(raw, str) else jsonify(raw)


@app.route("/api/demographics/<patient_id>", methods=["GET"])
def demographics(patient_id):
    raw = backend.get_demographics(patient_id)
    return jsonify({"raw": raw})


@app.route("/api/demographics/<patient_id>", methods=["POST"])
def update_demographics(patient_id):
    fields = request.get_json()
    raw = backend.update_demographics(patient_id, fields)
    return jsonify({"raw": raw})


@app.route("/api/insurance/<patient_id>", methods=["GET"])
def insurance(patient_id):
    raw = backend.get_insurance(patient_id)
    return jsonify({"raw": raw})


@app.route("/api/insurance/<patient_id>/confirm", methods=["POST"])
def confirm_insurance(patient_id):
    body = request.get_json()
    # NOTE: company/memberId/groupNumber/subscriberName are accepted here but
    # not yet written back anywhere — eCW's dispatch table (see reference doc)
    # never surfaced an "update insurance fields" action the way it did for
    # updateDemographics, only logInsuranceAccepted/Rejected. Until that's
    # confirmed against a real instance, edits here are logged as an
    # accept/reject decision but the edited values themselves aren't persisted.
    fields = {
        "company": body.get("company"), "memberId": body.get("memberId"),
        "groupNumber": body.get("groupNumber"), "subscriberName": body.get("subscriberName"),
    }
    raw = backend.confirm_insurance(patient_id, body["insuranceId"], body["accepted"], fields=fields)
    return jsonify({"raw": raw})


@app.route("/api/insurance/<patient_id>/self-pay", methods=["POST"])
def insurance_self_pay(patient_id):
    raw = backend.log_self_pay(patient_id)
    return jsonify({"raw": raw})


@app.route("/api/insurance/<patient_id>/card-photo", methods=["POST"])
def insurance_card_photo(patient_id):
    body = request.get_json()
    png_bytes = base64.b64decode(body["imagePngBase64"])
    raw = backend.save_insurance_card(patient_id, png_bytes)
    return jsonify({"raw": raw})


@app.route("/api/consent-forms/<patient_id>", methods=["GET"])
def consent_forms(patient_id):
    raw = backend.get_consent_forms(patient_id)
    return jsonify({"raw": raw})


@app.route("/api/signature/<patient_id>", methods=["POST"])
def signature(patient_id):
    body = request.get_json()
    png_bytes = base64.b64decode(body["signaturePngBase64"])
    raw = backend.save_signature(patient_id, body["formType"], png_bytes)
    return jsonify({"raw": raw})


@app.route("/api/questionnaires/<patient_id>", methods=["GET"])
def questionnaire_list(patient_id):
    encounter_id = request.args.get("encounterId")
    data = backend.get_questionnaire_list(patient_id, encounter_id)
    return jsonify(data)


@app.route("/api/questionnaire", methods=["GET"])
def questionnaire():
    name = request.args.get("name", "Reason for Visit")
    data = backend.get_questionnaire(name)
    return jsonify(data)


@app.route("/api/questionnaire/<patient_id>/answers", methods=["GET"])
def questionnaire_answers(patient_id):
    name = request.args.get("name", "")
    data = backend.get_questionnaire_answers(patient_id, name)
    return jsonify(data)


@app.route("/api/questionnaire/<patient_id>", methods=["POST"])
def save_questionnaire(patient_id):
    body = request.get_json()
    name = body.get("name", "Reason for Visit")
    answers = body.get("answers", {})
    result = backend.save_questionnaire_answers(patient_id, name, answers)
    return jsonify(result)


@app.route("/api/medical-history/<patient_id>", methods=["GET"])
def medical_history(patient_id):
    raw = backend.get_medical_history(patient_id)
    return jsonify({"raw": raw})


@app.route("/api/immunization/<patient_id>", methods=["GET"])
def immunization(patient_id):
    raw = backend.get_immunization_questionnaire(patient_id)
    return jsonify({"raw": raw})


@app.route("/api/immunization/<patient_id>", methods=["POST"])
def save_immunization(patient_id):
    answers = request.get_json()
    raw = backend.save_immunization_answers(patient_id, answers)
    return jsonify({"raw": raw})


@app.route("/api/check-in", methods=["POST"])
def check_in():
    body = request.get_json()
    raw = backend.check_in(body["patientId"], body["encounterId"])
    return jsonify({"raw": raw})


@app.route("/api/complete", methods=["POST"])
def complete():
    body = request.get_json()
    raw = backend.complete_visit(body["patientId"], body.get("tasksCompleted", []))
    return jsonify({"raw": raw})


if __name__ == "__main__":
    app.run(debug=True, port=5000)
