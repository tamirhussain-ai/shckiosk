"""
Configuration for the custom check-in app.

Fill in the real values below once you have a test/sandbox eCW instance
to point at. Until then, MOCK_MODE=True makes ecw_native_client.py return
realistic canned responses instead of making real network calls, so the
rest of the app can be built and demoed end to end.
"""

# --- Mode -------------------------------------------------------------
MOCK_MODE = True  # flip to False once ECW_HOST/ACTIVATION_CODE/REG_KEY are real

# --- Native kiosk protocol (reverse-engineered from IpadKioskProcessor) --
ECW_HOST = "https://your-ecw-host.example.org"     # base URL of the mobiledoc webapp
ECW_KIOSK_PATH = "/mobiledoc/IpadKioskProcessor"    # servlet path — confirm against your WAR
FACILITY_ACTIVATION_CODE = "REPLACE_ME"             # issued per-facility by eCW
REG_KEY = "REPLACE_ME"                              # sent as the `rk` request header
FACILITY_ID = "REPLACE_ME"                          # numeric facId used in validateUser etc.

# This is the exact boundary string eCW's saveSignature handler looks for.
# It was hardcoded in their servlet rather than read from the Content-Type
# header — re-verify this hasn't changed before relying on it in production.
SAVE_SIGNATURE_BOUNDARY = "WebKitFormBoundarycC4YiaUFwM44F6rT"

# --- REST API (ehr-restful-api-main, already used by the online scheduler) --
REST_API_BASE = "https://your-rest-api-host.example.org/api"
REST_API_KEY = "REPLACE_ME"

# --- Per-step routing: "native" or "rest" ------------------------------
# Lets you flip individual steps to the REST API as you confirm what it
# covers, without touching the wizard or the frontend.
STEP_CLIENT = {
    "identify_patient": "native",
    "get_encounters": "rest",       # falls back to native if REST doesn't have it
    "get_demographics": "native",
    "update_demographics": "native",
    "get_insurance": "native",
    "verify_eligibility": "native",
    "log_insurance_decision": "native",
    "get_consent_forms": "native",
    "save_signature": "native",
    "get_medical_history": "native",
    "save_surgical_history": "native",
    "get_immunization_questionnaire": "native",
    "save_immunization_questionnaire": "native",
    "check_in": "native",           # must be native — this is what drives the tracking board
    "complete_visit": "native",
}

# --- Your own MySQL-based questionnaire subsystem ----------------------
# Reused as-is from the branching questionnaire renderer prototype —
# NOT eCW's own getQuestionnaire/saveQuestionnaire.
QUESTIONNAIRE_DB = {
    "host": "REPLACE_ME",
    "user": "REPLACE_ME",
    "password": "REPLACE_ME",
    "database": "REPLACE_ME",
}
